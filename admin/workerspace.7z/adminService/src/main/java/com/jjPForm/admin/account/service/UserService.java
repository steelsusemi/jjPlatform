package com.jjPForm.admin.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jjPForm.admin.account.repository.UserRepository;
import com.jjPForm.core.account.vo.Role;
import com.jjPForm.core.account.vo.User;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	public User save(User user) {
		user.setEnabled(true);
		
		Role role = new Role();
		role.setId(1l);
		user.getRoles().add(0, role);
		
		return userRepository.save(user);
	}
}
