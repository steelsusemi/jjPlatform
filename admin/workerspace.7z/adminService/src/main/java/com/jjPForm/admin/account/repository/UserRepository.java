package com.jjPForm.admin.account.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jjPForm.core.account.vo.User;


public interface UserRepository extends JpaRepository<User, Long>{
	User findByUsername(String username);
}
