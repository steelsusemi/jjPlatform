package com.jjPForm.admin.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jjPForm.admin.account.repository.UserRepository;
import com.jjPForm.admin.board.repository.BoardRepository;
import com.jjPForm.core.account.vo.User;
import com.jjPForm.core.board.vo.Board;

@Service
public class BoardService {
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	public Board save(Board board) {
		User user = userRepository.findByUsername(board.getUser().getUsername());
		board.setUser(user);
		
		return boardRepository.save(board);
		
	}
}
