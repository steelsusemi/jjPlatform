package com.jjPForm.core.account.vo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.jjPForm.core.board.vo.Board;

import javax.persistence.JoinColumn;

import lombok.Data;

@Entity
@Data
public class TestVo {
	private String id  ; 
	private String text; 
	private String type; 
	private BigDecimal tot ; 
	private BigDecimal tot1 ; 

     public TestVo(String id, String text, String type, BigDecimal tot, BigDecimal tot1) {
         this.id = id;
         this.text = text;
         this.type = type;
         this.tot = tot;
         this.tot1 = tot1;
     }
}
